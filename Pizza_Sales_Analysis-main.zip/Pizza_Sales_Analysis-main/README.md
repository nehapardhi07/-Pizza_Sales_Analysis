# Pizza Sales Analysis Using SQL & Power Bi
![](https://www.tastingtable.com/img/gallery/why-the-position-of-your-oven-rack-matters-for-pizza/intro-1664372305.jpg)

# OVERVIEW
This project focuses on analyzing a real-world pizza sales dataset using SQL for data querying and business analysis and Power BI for interactive dashboard visualization. The objective was to extract meaningful business insights related to sales performance, customer behavior, and product trends.
The dataset was first explored and analyzed using advanced SQL queries including GROUP BY, CTEs, and Window Functions to calculate KPIs and identify trends. The derived insights were then visualized in Power BI through dynamic dashboards to support data-driven decision-making.

# OBJECTIVE
* Analyze overall sales performance and calculate key KPIs like total revenue, total orders, and average order value.
* Identify top-performing pizzas based on revenue, quantity sold, and category contribution.
* Examine monthly and seasonal sales trends to understand demand patterns.
* Compare sales performance across pizza sizes and categories to detect business opportunities.
* Generate data-driven insights using SQL and present them through interactive Power BI dashboards.




